import homeController from './controllers/home'
import positionController from './controllers/position'

homeController.render()
positionController.render()