import searchTpl from '../views/search.html'

const render = () => {
  $('main').html(searchTpl)
}

export default {
  render
}